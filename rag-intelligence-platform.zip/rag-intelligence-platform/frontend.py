import os
import streamlit as st
import requests

st.set_page_config(page_title="RAG Intelligence", page_icon="🧠", layout="wide")
API_URL = st.sidebar.text_input("API URL", os.getenv("API_URL", "http://localhost:8000"))

st.title("🧠 Enterprise RAG Intelligence")
st.caption("Upload internal knowledge documents and ask questions grounded in their content.")

with st.sidebar:
    st.subheader("Knowledge base")
    if st.button("Check API health"):
        try:
            response = requests.get(f"{API_URL}/health", timeout=10)
            response.raise_for_status()
            st.success(f"API online · {response.json()['indexed_chunks']} indexed chunks")
        except requests.RequestException as exc:
            st.error(str(exc))

uploaded = st.file_uploader("Upload a PDF, DOCX, TXT or Markdown file",
                            type=["pdf", "docx", "txt", "md"])
if uploaded and st.button("Index document", type="primary"):
    try:
        response = requests.post(
            f"{API_URL}/documents",
            files={"file": (uploaded.name, uploaded.getvalue(), uploaded.type)},
            timeout=180
        )
        response.raise_for_status()
        result = response.json()
        st.success(f"Indexed {result['chunks_indexed']} chunks from {result['filename']}")
        st.json(result)
    except requests.RequestException as exc:
        st.error(f"Upload failed: {exc}")

st.divider()
question = st.text_area("Ask a question about your uploaded documents",
                        placeholder="What does the policy say about transaction disputes?")
if st.button("Ask knowledge base", type="primary", disabled=not question.strip()):
    with st.spinner("Retrieving relevant passages and generating an answer..."):
        try:
            response = requests.post(
                f"{API_URL}/ask", json={"question": question}, timeout=180
            )
            response.raise_for_status()
            result = response.json()
            st.subheader("Answer")
            st.write(result["answer"])
            st.subheader("Retrieved sources")
            if not result["sources"]:
                st.info("No relevant sources were retrieved.")
            for source in result["sources"]:
                label = f"{source['filename']} · page {source['page'] or 'N/A'} · chunk {source['chunk']}"
                with st.expander(label):
                    st.write(source["excerpt"])
                    st.caption(f"Retrieval distance: {source['distance']:.4f}")
        except requests.RequestException as exc:
            st.error(f"Request failed: {exc}")
