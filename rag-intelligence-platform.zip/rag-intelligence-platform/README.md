# Enterprise RAG Intelligence Platform

A portfolio project demonstrating document ingestion, text chunking, dense-vector retrieval, and retrieval-grounded question answering through a REST API and Streamlit interface.

## Architecture

1. **Ingestion:** accepts PDF, DOCX, TXT and Markdown documents.
2. **Extraction:** extracts page-aware text where possible.
3. **Chunking:** creates overlapping text windows to preserve context.
4. **Embeddings:** uses Sentence Transformers (`all-MiniLM-L6-v2`).
5. **Vector database:** stores embeddings and metadata in persistent ChromaDB.
6. **Retrieval:** performs semantic nearest-neighbour search.
7. **Generation:** optionally sends retrieved context to an OpenAI-compatible chat model.
8. **Presentation:** exposes FastAPI endpoints and a Streamlit user interface.

## Project structure

```text
rag-intelligence-platform/
├── app/
│   ├── config.py
│   ├── document_loader.py
│   ├── chunking.py
│   ├── vector_store.py
│   ├── rag.py
│   ├── schemas.py
│   └── main.py
├── tests/
│   └── test_chunking.py
├── frontend.py
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
├── .env.example
└── README.md
```

## Run locally (Windows PowerShell)

```powershell
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

Add your model-provider API key to `.env` if you want generated answers. Without a key, retrieval still works and the API returns retrieved passages rather than generated prose.

Start the API in terminal 1:

```powershell
uvicorn app.main:app --reload
```

Start the UI in terminal 2:

```powershell
streamlit run frontend.py
```

Open `http://localhost:8501`. API documentation is available at `http://localhost:8000/docs`.

## Run tests

```powershell
pytest -q
```

## Run with Docker

Create `.env` from `.env.example`, then:

```bash
docker compose up --build
```

The API is exposed on port 8000 and the UI on port 8501. Persistent Chroma data is stored in a Docker volume.

## API

### `GET /health`
Returns service status and indexed chunk count.

### `POST /documents`
Multipart upload of a supported document. Returns document ID and number of indexed chunks.

### `POST /ask`
Example JSON:

```json
{
  "question": "What does the uploaded policy say about transaction disputes?",
  "top_k": 5
}
```

Returns an answer and source metadata including filename, page, chunk, and retrieved excerpt.

## Engineering notes and next improvements

- Add authentication, authorization and per-tenant collection isolation before exposing this service to real customers.
- Add file-size limits, malware scanning, rate limiting and request quotas.
- Add document deletion and re-indexing endpoints.
- Add OCR for scanned PDFs.
- Add reranking and retrieval-quality evaluation (Recall@K, MRR, faithfulness).
- Add structured logs, tracing, metrics and CI.
- Use a managed vector database and managed secrets in a production deployment.
- Review data retention, encryption and privacy requirements before processing sensitive financial documents.

## Important

This is a learning and portfolio implementation, not a production-certified financial service. Do not upload real customer data or secrets. Benchmark retrieval quality and test security controls before any production use.
