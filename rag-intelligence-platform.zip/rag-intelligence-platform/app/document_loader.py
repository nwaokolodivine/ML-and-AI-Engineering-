from pathlib import Path
from pypdf import PdfReader
from docx import Document as DocxDocument

SUPPORTED = {".pdf", ".docx", ".txt", ".md"}

def load_document(path: str | Path) -> list[dict]:
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix not in SUPPORTED:
        raise ValueError(f"Unsupported file type: {suffix}. Use PDF, DOCX, TXT or MD.")

    pages: list[dict] = []
    if suffix == ".pdf":
        reader = PdfReader(str(path))
        for index, page in enumerate(reader.pages, start=1):
            pages.append({"text": page.extract_text() or "", "page": index})
    elif suffix == ".docx":
        doc = DocxDocument(str(path))
        text = "\n".join(p.text for p in doc.paragraphs if p.text.strip())
        pages.append({"text": text, "page": None})
    else:
        pages.append({"text": path.read_text(encoding="utf-8", errors="replace"), "page": None})

    if not any(p["text"].strip() for p in pages):
        raise ValueError("No readable text was found in this document.")
    return pages
