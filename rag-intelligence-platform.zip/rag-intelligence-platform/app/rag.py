from openai import OpenAI
from app.config import settings
from app.vector_store import VectorStore

SYSTEM_PROMPT = """You are a careful enterprise knowledge assistant.
Answer using only the supplied context. If the context does not contain the answer,
say that you cannot find enough information in the uploaded documents.
Do not invent policies, payment statuses, account details, figures, or citations.
Distinguish facts from reasonable interpretation. Keep answers concise and useful."""

class RAGService:
    def __init__(self, store: VectorStore):
        self.store = store
        self.client = None
        if settings.openai_api_key:
            kwargs = {"api_key": settings.openai_api_key}
            if settings.openai_base_url:
                kwargs["base_url"] = settings.openai_base_url
            self.client = OpenAI(**kwargs)

    def answer(self, question: str, top_k: int | None = None):
        matches = self.store.search(question, top_k or settings.retrieval_k)
        if not matches:
            return "I couldn't find relevant information in the indexed documents.", []

        context_parts = []
        for i, match in enumerate(matches, start=1):
            meta = match["metadata"]
            context_parts.append(
                f"[Source {i}: {meta.get('filename')} | page {meta.get('page') or 'N/A'}]\n"
                f"{match['text']}"
            )
        context = "\n\n".join(context_parts)

        if self.client:
            completion = self.client.chat.completions.create(
                model=settings.llm_model,
                temperature=0.1,
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": f"CONTEXT:\n{context}\n\nQUESTION:\n{question}"}
                ]
            )
            answer = completion.choices[0].message.content or ""
        else:
            answer = (
                "LLM generation is not configured. The most relevant retrieved passages "
                "are shown below. Add OPENAI_API_KEY to your environment to enable "
                "context-grounded natural-language answers.\n\n" +
                "\n\n".join(f"- {m['text'][:700]}" for m in matches[:3])
            )

        return answer, matches
