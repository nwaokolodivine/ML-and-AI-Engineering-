from pathlib import Path
from sentence_transformers import SentenceTransformer
import chromadb
from app.config import settings

class VectorStore:
    def __init__(self):
        Path(settings.chroma_path).mkdir(parents=True, exist_ok=True)
        self.client = chromadb.PersistentClient(path=settings.chroma_path)
        self.collection = self.client.get_or_create_collection(
            name=settings.collection_name,
            metadata={"hnsw:space": "cosine"}
        )
        self.encoder = SentenceTransformer(settings.embedding_model)

    def add_chunks(self, chunks: list[str], metadatas: list[dict], ids: list[str]) -> None:
        if not chunks:
            return
        embeddings = self.encoder.encode(chunks, normalize_embeddings=True).tolist()
        self.collection.upsert(
            ids=ids, documents=chunks, metadatas=metadatas, embeddings=embeddings
        )

    def search(self, question: str, top_k: int):
        embedding = self.encoder.encode([question], normalize_embeddings=True).tolist()
        result = self.collection.query(
            query_embeddings=embedding,
            n_results=top_k,
            include=["documents", "metadatas", "distances"]
        )
        matches = []
        docs = (result.get("documents") or [[]])[0]
        metas = (result.get("metadatas") or [[]])[0]
        distances = (result.get("distances") or [[]])[0]
        for doc, meta, distance in zip(docs, metas, distances):
            matches.append({"text": doc, "metadata": meta, "distance": float(distance)})
        return matches

    def count(self) -> int:
        return self.collection.count()
