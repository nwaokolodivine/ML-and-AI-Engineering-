from pydantic import BaseModel, Field

class AskRequest(BaseModel):
    question: str = Field(min_length=3, max_length=2000)
    top_k: int | None = Field(default=None, ge=1, le=10)

class Source(BaseModel):
    document_id: str
    filename: str
    page: int | None = None
    chunk: int
    distance: float | None = None
    excerpt: str

class AskResponse(BaseModel):
    answer: str
    grounded: bool
    sources: list[Source]

class UploadResponse(BaseModel):
    document_id: str
    filename: str
    chunks_indexed: int
    message: str
