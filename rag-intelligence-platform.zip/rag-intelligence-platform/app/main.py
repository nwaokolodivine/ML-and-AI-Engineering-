from pathlib import Path
from uuid import uuid4
import shutil
from fastapi import FastAPI, UploadFile, File, HTTPException
from app.config import settings
from app.schemas import AskRequest, AskResponse, Source, UploadResponse
from app.document_loader import load_document, SUPPORTED
from app.chunking import chunk_text
from app.vector_store import VectorStore
from app.rag import RAGService

app = FastAPI(title=settings.app_name, version="1.0.0",
              description="Document ingestion, semantic retrieval and grounded Q&A API.")
store = VectorStore()
rag = RAGService(store)
UPLOAD_DIR = Path("./data/uploads")
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

@app.get("/health")
def health():
    return {"status": "ok", "indexed_chunks": store.count()}

@app.post("/documents", response_model=UploadResponse)
async def upload_document(file: UploadFile = File(...)):
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in SUPPORTED:
        raise HTTPException(400, "Supported formats: PDF, DOCX, TXT, MD.")
    document_id = str(uuid4())
    safe_name = Path(file.filename or "upload").name
    destination = UPLOAD_DIR / f"{document_id}_{safe_name}"
    try:
        with destination.open("wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        pages = load_document(destination)
        texts, metadata, ids = [], [], []
        chunk_index = 0
        for page_data in pages:
            chunks = chunk_text(page_data["text"], settings.chunk_size, settings.chunk_overlap)
            for chunk in chunks:
                texts.append(chunk)
                metadata.append({
                    "document_id": document_id,
                    "filename": safe_name,
                    "page": page_data["page"] or 0,
                    "chunk": chunk_index
                })
                ids.append(f"{document_id}_{chunk_index}")
                chunk_index += 1
        store.add_chunks(texts, metadata, ids)
        return UploadResponse(
            document_id=document_id, filename=safe_name,
            chunks_indexed=len(texts), message="Document indexed successfully."
        )
    except ValueError as exc:
        destination.unlink(missing_ok=True)
        raise HTTPException(400, str(exc))
    except Exception as exc:
        destination.unlink(missing_ok=True)
        raise HTTPException(500, f"Document processing failed: {exc}")

@app.post("/ask", response_model=AskResponse)
def ask(request: AskRequest):
    try:
        answer, matches = rag.answer(request.question, request.top_k)
        sources = []
        for match in matches:
            meta = match["metadata"]
            sources.append(Source(
                document_id=meta.get("document_id", ""),
                filename=meta.get("filename", "unknown"),
                page=meta.get("page"),
                chunk=int(meta.get("chunk", 0)),
                distance=match["distance"],
                excerpt=match["text"][:350]
            ))
        return AskResponse(answer=answer, grounded=bool(matches), sources=sources)
    except Exception as exc:
        raise HTTPException(500, f"Question answering failed: {exc}")
