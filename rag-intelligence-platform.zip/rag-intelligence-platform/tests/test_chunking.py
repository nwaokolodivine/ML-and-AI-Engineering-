import pytest
from app.chunking import chunk_text

def test_empty_text_returns_no_chunks():
    assert chunk_text("") == []

def test_chunks_overlap_and_cover_text():
    chunks = chunk_text("one two three four five six", chunk_size=4, overlap=2)
    assert chunks == ["one two three four", "three four five six"]

def test_invalid_overlap_raises():
    with pytest.raises(ValueError):
        chunk_text("some text", chunk_size=5, overlap=5)
