# PaymentPulse — Payment Analytics & Transaction Monitoring

PaymentPulse is an end-to-end analytics application for exploring payment transaction performance. It ingests transaction CSVs, validates and normalises records, computes operational KPIs, analyses merchant performance and flags potential daily failure-rate spikes for investigation.

> **Data notice:** The included demo data is synthetic. Metrics and spike flags are illustrative and must not be represented as live processor performance or confirmed incidents.

## Capabilities

- CSV ingestion with schema, timestamp, status, amount and duplicate-ID validation.
- Transaction success, failure, pending and reversal metrics.
- Gross and successful transaction value.
- Median and 95th-percentile successful payment latency.
- Daily transaction trends by status.
- Merchant-level transaction volumes, failure counts, values and success rates.
- Exploratory IQR-based failure-rate spike screening.
- SQLite persistence and indexed transaction queries.
- FastAPI analytics and transaction endpoints.
- Streamlit dashboard and CSV export.
- Unit and API tests plus GitHub Actions CI.
- Docker and Docker Compose.

## Architecture

```mermaid
flowchart TD
  A[Transaction CSV] --> B[FastAPI upload endpoint]
  B --> C[Schema and data validation]
  C --> D[Pandas analytics pipeline]
  D --> E[KPI calculations]
  D --> F[Daily and merchant aggregates]
  D --> G[Failure spike screening]
  C --> H[SQLite storage]
  E --> I[Streamlit dashboard]
  F --> I
  G --> I
  H --> J[Transaction query endpoint]
  J --> I
```

## Run locally on Windows

Use Python 3.11.

```powershell
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m paymentpulse.demo_data
```

Start the API in terminal 1:

```powershell
uvicorn paymentpulse.api:app --reload
```

Start the dashboard in terminal 2:

```powershell
streamlit run dashboard.py
```

Open `http://localhost:8501`, upload `data/demo_transactions.csv`, and run the analytics. API docs are at `http://localhost:8000/docs`.

## Tests

```powershell
pytest -q
```

GitHub Actions runs the same tests on pushes and pull requests.

## Docker

```powershell
docker compose up --build
```

The API is exposed on port 8000 and the dashboard on port 8501.

## Input schema

The uploaded CSV must contain:

| Column | Description |
|---|---|
| transaction_id | Unique transaction identifier |
| merchant_id | Merchant identifier |
| amount | Non-negative transaction amount |
| currency | Currency code |
| status | SUCCESS, FAILED, PENDING or REVERSED |
| created_at | ISO-8601 transaction creation timestamp |
| completed_at | ISO-8601 completion timestamp; blank if incomplete |
| payment_method | Payment channel or method |

Naive timestamps are interpreted as UTC. Currency and status values are normalised to uppercase. The application currently aggregates amounts as supplied and does not perform currency conversion; totals across currencies must not be interpreted as a single-currency financial total.

## KPI definitions

- Success rate = successful transaction count / all transaction count.
- Failure rate = failed transaction count / all transaction count.
- Successful transaction value = sum of amounts for SUCCESS records.
- Processing latency = completed_at minus created_at for successful transactions.
- Merchant success rate = successful count / merchant transaction count.

## Failure-spike screening

The dashboard uses an exploratory interquartile-range rule on merchant/day failure rates, after filtering groups below a configurable minimum transaction count in the analytics function. This is a simple screening heuristic, not a calibrated anomaly-detection model. A flagged group requires investigation and is not proof of fraud, an outage, or a processor incident.

## API

- `GET /health` — service health.
- `POST /analytics` — upload a CSV and receive KPIs, daily trends, merchant performance and failure-spike screening.
- `GET /transactions?limit=1000` — retrieve most recently stored transactions.

## Production considerations

This is a portfolio prototype. It does not include authentication, role-based access control, upload-size limits, pagination beyond a simple limit, multi-tenant data isolation, streaming ingestion, currency conversion, event-time watermarking, alert delivery, or a production observability stack. A production service would require security controls, privacy review, data retention policies, durable ingestion, monitoring, alert governance, and load testing.

## Interview topics

Be prepared to explain:
1. Why schema validation and duplicate-ID checks happen before analytics.
2. How success rate and processing latency are defined.
3. Why median and p95 latency complement each other.
4. Why multi-currency totals cannot be combined without FX conversion.
5. How the IQR screening rule works and where it can fail.
6. How you would scale ingestion and analytics for streaming payment events.
