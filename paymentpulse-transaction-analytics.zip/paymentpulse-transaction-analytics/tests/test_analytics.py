import pandas as pd
from paymentpulse.analytics import build_kpis, merchant_performance, detect_failure_spikes


def sample_frame():
    return pd.DataFrame({
        "transaction_id": ["1", "2", "3", "4"],
        "merchant_id": ["a", "a", "b", "b"],
        "amount": [100.0, 200.0, 300.0, 400.0],
        "status": ["SUCCESS", "FAILED", "SUCCESS", "PENDING"],
        "latency_seconds": [10.0, None, 20.0, None],
        "event_date": ["2026-01-01"] * 4,
    })


def test_kpis_are_correct():
    kpis = build_kpis(sample_frame())
    assert kpis["transaction_count"] == 4
    assert kpis["success_rate"] == 0.5
    assert kpis["failure_rate"] == 0.25
    assert kpis["successful_transaction_value"] == 400.0
    assert kpis["median_success_latency_seconds"] == 15.0


def test_merchant_performance():
    result = merchant_performance(sample_frame()).set_index("merchant_id")
    assert result.loc["a", "transaction_count"] == 2
    assert result.loc["a", "success_rate"] == 0.5


def test_spike_detector_handles_small_groups():
    result = detect_failure_spikes(sample_frame(), min_transactions=10)
    assert result.empty
