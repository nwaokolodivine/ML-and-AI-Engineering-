import io
import pandas as pd
import pytest
from paymentpulse.ingestion import load_transactions


CSV = """transaction_id,merchant_id,amount,currency,status,created_at,completed_at,payment_method
t1,m1,100.25,ngn,SUCCESS,2026-01-01T10:00:00Z,2026-01-01T10:00:10Z,CARD
t2,m2,200,NGN,FAILED,2026-01-01T11:00:00Z,,TRANSFER
"""


def test_loads_and_normalises():
    frame = load_transactions(io.BytesIO(CSV.encode()))
    assert frame.loc[0, "currency"] == "NGN"
    assert frame.loc[0, "latency_seconds"] == 10
    assert pd.isna(frame.loc[1, "latency_seconds"])


def test_duplicate_ids_rejected():
    duplicate = CSV + "t1,m3,50,NGN,FAILED,2026-01-01T12:00:00Z,,CARD\n"
    with pytest.raises(ValueError, match="Duplicate"):
        load_transactions(io.BytesIO(duplicate.encode()))


def test_missing_column_rejected():
    with pytest.raises(ValueError, match="Missing required columns"):
        load_transactions(io.BytesIO(b"transaction_id,amount\nt1,100\n"))


def test_negative_amount_rejected():
    bad = CSV.replace("100.25", "-100")
    with pytest.raises(ValueError, match="non-negative"):
        load_transactions(io.BytesIO(bad.encode()))


def test_completion_before_creation_rejected():
    bad = CSV.replace("2026-01-01T10:00:10Z", "2026-01-01T09:00:00Z")
    with pytest.raises(ValueError, match="earlier"):
        load_transactions(io.BytesIO(bad.encode()))
