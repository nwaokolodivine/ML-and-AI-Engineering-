from fastapi.testclient import TestClient
from paymentpulse.api import app


def test_health():
    with TestClient(app) as client:
        response = client.get("/health")
    assert response.status_code == 200


def test_analytics_upload(monkeypatch):
    import paymentpulse.api as api
    monkeypatch.setattr(api, "save_transactions", lambda frame: len(frame))
    content = (
        "transaction_id,merchant_id,amount,currency,status,created_at,completed_at,payment_method\n"
        "t1,m1,100,NGN,SUCCESS,2026-01-01T10:00:00Z,2026-01-01T10:00:05Z,CARD\n"
        "t2,m1,200,NGN,FAILED,2026-01-01T11:00:00Z,,TRANSFER\n"
    )
    with TestClient(app) as client:
        response = client.post(
            "/analytics",
            files={"file": ("payments.csv", content, "text/csv")},
        )
    assert response.status_code == 200
    assert response.json()["kpis"]["transaction_count"] == 2


def test_bad_csv_returns_400():
    with TestClient(app) as client:
        response = client.post(
            "/analytics",
            files={"file": ("bad.csv", "id,amount\nx,1", "text/csv")},
        )
    assert response.status_code == 400
