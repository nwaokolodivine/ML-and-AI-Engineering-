import os
import requests
import pandas as pd
import streamlit as st

st.set_page_config(page_title="PaymentPulse", page_icon="📈", layout="wide")
st.title("📈 PaymentPulse")
st.caption("Payment analytics & transaction monitoring · synthetic-data portfolio demo")
api_url = st.sidebar.text_input("API URL", os.getenv("API_URL", "http://localhost:8000"))

uploaded = st.file_uploader("Upload transaction CSV", type=["csv"])
if uploaded and st.button("Analyse payments", type="primary"):
    try:
        response = requests.post(
            f"{api_url}/analytics",
            files={"file": (uploaded.name, uploaded.getvalue(), "text/csv")},
            timeout=60,
        )
        response.raise_for_status()
        st.session_state["analysis"] = response.json()
    except requests.RequestException as exc:
        st.error(f"Analytics request failed: {exc}")
        if getattr(exc, "response", None) is not None:
            st.error(exc.response.text)

result = st.session_state.get("analysis")
if result:
    k = result["kpis"]
    st.divider()
    st.subheader("Payment performance overview")
    cols = st.columns(4)
    cols[0].metric("Transactions", f"{k['transaction_count']:,}")
    cols[1].metric("Success rate", f"{k['success_rate']:.1%}")
    cols[2].metric("Failure rate", f"{k['failure_rate']:.1%}")
    cols[3].metric("Successful value", f"{k['successful_transaction_value']:,.2f}")
    cols = st.columns(4)
    cols[0].metric("Successful", f"{k['success_count']:,}")
    cols[1].metric("Failed", f"{k['failed_count']:,}")
    cols[2].metric("Pending", f"{k['pending_count']:,}")
    cols[3].metric("Reversed", f"{k['reversed_count']:,}")

    st.subheader("Processing latency")
    c1, c2 = st.columns(2)
    c1.metric("Median success latency", "N/A" if k["median_success_latency_seconds"] is None else f"{k['median_success_latency_seconds']:.1f} sec")
    c2.metric("95th percentile latency", "N/A" if k["p95_success_latency_seconds"] is None else f"{k['p95_success_latency_seconds']:.1f} sec")

    daily = pd.DataFrame(result["daily_trends"])
    if not daily.empty:
        st.subheader("Daily transaction volume by status")
        pivot = daily.pivot(index="event_date", columns="status", values="transaction_count").fillna(0)
        st.bar_chart(pivot)

    merchants = pd.DataFrame(result["merchant_performance"])
    if not merchants.empty:
        st.subheader("Merchant performance")
        st.dataframe(merchants, use_container_width=True, hide_index=True)

    spikes = pd.DataFrame(result["failure_spikes"])
    st.subheader("Potential failure-rate spikes")
    if spikes.empty or not spikes["is_failure_spike"].any():
        st.info("No groups crossed the current IQR screening threshold.")
    else:
        st.dataframe(spikes[spikes["is_failure_spike"]], use_container_width=True, hide_index=True)
    st.caption("Failure-spike flags are exploratory IQR-based screening signals, not proof of an incident or fraud.")
    st.download_button(
        "Download merchant performance CSV",
        merchants.to_csv(index=False).encode("utf-8"),
        file_name="merchant_performance.csv",
        mime="text/csv",
    )
