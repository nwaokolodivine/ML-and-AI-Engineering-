from fastapi import FastAPI, File, HTTPException, UploadFile
import io
import pandas as pd
from paymentpulse.ingestion import load_transactions
from paymentpulse.analytics import build_kpis, daily_trends, merchant_performance, detect_failure_spikes
from paymentpulse.storage import save_transactions, query_transactions

app = FastAPI(
    title="PaymentPulse API",
    version="1.0.0",
    description="Payment analytics and operational monitoring demo using uploaded transaction data.",
)


@app.get("/health")
def health():
    return {"status": "ok", "service": "paymentpulse-api"}


@app.post("/analytics")
async def analytics(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(".csv"):
        raise HTTPException(status_code=415, detail="Upload a CSV file.")
    try:
        frame = load_transactions(io.BytesIO(await file.read()))
        save_transactions(frame)
        return {
            "kpis": build_kpis(frame),
            "daily_trends": daily_trends(frame).to_dict(orient="records"),
            "merchant_performance": merchant_performance(frame).to_dict(orient="records"),
            "failure_spikes": detect_failure_spikes(frame).to_dict(orient="records"),
            "records_stored": len(frame),
        }
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/transactions")
def transactions(limit: int = 1000):
    if limit < 1 or limit > 10000:
        raise HTTPException(status_code=422, detail="limit must be between 1 and 10000.")
    return {"transactions": query_transactions(limit)}
