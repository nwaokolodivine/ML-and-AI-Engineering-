from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "paymentpulse.db"

REQUIRED_COLUMNS = {
    "transaction_id", "merchant_id", "amount", "currency",
    "status", "created_at", "completed_at", "payment_method",
}
