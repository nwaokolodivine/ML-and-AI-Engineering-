import sqlite3
from paymentpulse.config import DB_PATH, DATA_DIR


def save_transactions(frame):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    stored = frame.copy()
    stored["created_at"] = stored["created_at"].astype(str)
    stored["completed_at"] = stored["completed_at"].astype(str)
    with sqlite3.connect(DB_PATH) as connection:
        stored.to_sql("transactions", connection, if_exists="replace", index=False)
        connection.execute("CREATE INDEX IF NOT EXISTS idx_txn_merchant ON transactions(merchant_id)")
        connection.execute("CREATE INDEX IF NOT EXISTS idx_txn_date ON transactions(event_date)")
        connection.execute("CREATE INDEX IF NOT EXISTS idx_txn_status ON transactions(status)")
    return int(len(stored))


def query_transactions(limit=1000):
    if not DB_PATH.exists():
        return []
    with sqlite3.connect(DB_PATH) as connection:
        cursor = connection.execute(
            "SELECT transaction_id, merchant_id, amount, currency, status, "
            "created_at, completed_at, payment_method, latency_seconds, event_date "
            "FROM transactions ORDER BY created_at DESC LIMIT ?",
            (limit,),
        )
        columns = [d[0] for d in cursor.description]
        return [dict(zip(columns, row)) for row in cursor.fetchall()]
