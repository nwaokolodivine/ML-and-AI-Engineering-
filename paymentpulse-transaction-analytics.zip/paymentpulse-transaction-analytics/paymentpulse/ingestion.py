from __future__ import annotations
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
import pandas as pd
from paymentpulse.config import REQUIRED_COLUMNS


def _parse_timestamp(value):
    if value is None or pd.isna(value) or str(value).strip() == "":
        return pd.NaT
    stamp = pd.Timestamp(value)
    if stamp.tzinfo is None:
        stamp = stamp.tz_localize("UTC")
    return stamp.tz_convert("UTC")


def load_transactions(csv_file) -> pd.DataFrame:
    """Load and validate a transaction CSV. Invalid records raise actionable errors."""
    try:
        frame = pd.read_csv(csv_file)
    except Exception as exc:
        raise ValueError(f"Could not read CSV: {exc}") from exc

    missing = REQUIRED_COLUMNS - set(frame.columns)
    if missing:
        raise ValueError(f"Missing required columns: {', '.join(sorted(missing))}")
    if frame.empty:
        raise ValueError("The CSV contains no transaction rows.")

    frame = frame.copy()
    for col in ("transaction_id", "merchant_id", "currency", "status", "payment_method"):
        frame[col] = frame[col].astype("string").str.strip()

    if frame["transaction_id"].isna().any() or (frame["transaction_id"] == "").any():
        raise ValueError("transaction_id cannot be empty.")
    if frame["transaction_id"].duplicated().any():
        duplicates = frame.loc[frame["transaction_id"].duplicated(), "transaction_id"].tolist()
        raise ValueError(f"Duplicate transaction_id values: {duplicates[:5]}")
    if frame[["merchant_id", "currency", "status", "payment_method"]].isna().any().any():
        raise ValueError("merchant_id, currency, status and payment_method cannot be empty.")

    try:
        amounts = frame["amount"].map(lambda x: Decimal(str(x)))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError("amount must contain valid decimal values.") from exc
    if any(not x.is_finite() or x < 0 for x in amounts):
        raise ValueError("amount values must be finite and non-negative.")
    frame["amount"] = amounts.map(float)
    frame["currency"] = frame["currency"].str.upper()
    frame["status"] = frame["status"].str.upper()
    frame["created_at"] = frame["created_at"].map(_parse_timestamp)
    frame["completed_at"] = frame["completed_at"].map(_parse_timestamp)

    if frame["created_at"].isna().any():
        raise ValueError("created_at must contain a valid timestamp for every transaction.")
    invalid_completion = (
        frame["completed_at"].notna()
        & (frame["completed_at"] < frame["created_at"])
    )
    if invalid_completion.any():
        raise ValueError("completed_at cannot be earlier than created_at.")

    known_statuses = {"SUCCESS", "FAILED", "PENDING", "REVERSED"}
    unknown = set(frame["status"].dropna().unique()) - known_statuses
    if unknown:
        raise ValueError(f"Unsupported status values: {sorted(unknown)}")

    frame["latency_seconds"] = (
        frame["completed_at"] - frame["created_at"]
    ).dt.total_seconds()
    frame.loc[frame["status"] != "SUCCESS", "latency_seconds"] = pd.NA
    frame["event_date"] = frame["created_at"].dt.date.astype(str)
    return frame
