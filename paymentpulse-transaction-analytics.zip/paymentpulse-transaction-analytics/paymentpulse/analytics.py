from __future__ import annotations
import pandas as pd


def _safe_rate(numerator, denominator):
    return float(numerator / denominator) if denominator else 0.0


def build_kpis(frame: pd.DataFrame) -> dict:
    total = int(len(frame))
    successful = int((frame["status"] == "SUCCESS").sum())
    failed = int((frame["status"] == "FAILED").sum())
    pending = int((frame["status"] == "PENDING").sum())
    reversed_count = int((frame["status"] == "REVERSED").sum())
    success_latency = frame.loc[
        (frame["status"] == "SUCCESS") & frame["latency_seconds"].notna(),
        "latency_seconds"
    ]
    return {
        "transaction_count": total,
        "success_count": successful,
        "failed_count": failed,
        "pending_count": pending,
        "reversed_count": reversed_count,
        "success_rate": _safe_rate(successful, total),
        "failure_rate": _safe_rate(failed, total),
        "gross_transaction_value": float(frame["amount"].sum()),
        "successful_transaction_value": float(
            frame.loc[frame["status"] == "SUCCESS", "amount"].sum()
        ),
        "median_success_latency_seconds": (
            float(success_latency.median()) if len(success_latency) else None
        ),
        "p95_success_latency_seconds": (
            float(success_latency.quantile(0.95)) if len(success_latency) else None
        ),
    }


def daily_trends(frame: pd.DataFrame) -> pd.DataFrame:
    grouped = frame.groupby(["event_date", "status"], dropna=False).agg(
        transaction_count=("transaction_id", "count"),
        transaction_value=("amount", "sum"),
    ).reset_index()
    return grouped.sort_values(["event_date", "status"])


def merchant_performance(frame: pd.DataFrame) -> pd.DataFrame:
    grouped = frame.groupby("merchant_id").agg(
        transaction_count=("transaction_id", "count"),
        successful=("status", lambda s: int((s == "SUCCESS").sum())),
        failed=("status", lambda s: int((s == "FAILED").sum())),
        gross_value=("amount", "sum"),
        median_latency_seconds=("latency_seconds", "median"),
    ).reset_index()
    grouped["success_rate"] = (
        grouped["successful"] / grouped["transaction_count"]
    )
    return grouped.sort_values(["transaction_count", "merchant_id"], ascending=[False, True])


def detect_failure_spikes(frame: pd.DataFrame, min_transactions: int = 5) -> pd.DataFrame:
    """Flag merchant/day groups with unusually high failure rates using a robust IQR rule.

    This is an operational screening heuristic, not a statistical guarantee or fraud label.
    """
    daily = frame.groupby(["event_date", "merchant_id"]).agg(
        transaction_count=("transaction_id", "count"),
        failed_count=("status", lambda s: int((s == "FAILED").sum())),
    ).reset_index()
    daily = daily[daily["transaction_count"] >= min_transactions].copy()
    if daily.empty:
        daily["failure_rate"] = pd.Series(dtype=float)
        daily["is_failure_spike"] = pd.Series(dtype=bool)
        return daily

    daily["failure_rate"] = daily["failed_count"] / daily["transaction_count"]
    q1 = daily["failure_rate"].quantile(0.25)
    q3 = daily["failure_rate"].quantile(0.75)
    iqr = q3 - q1
    upper = min(1.0, q3 + 1.5 * iqr)
    # Avoid flagging a uniformly high baseline solely because IQR is zero.
    daily["is_failure_spike"] = (
        (daily["failure_rate"] > upper)
        & (daily["failure_rate"] > 0)
    )
    daily["baseline_upper_bound"] = float(upper)
    return daily.sort_values(["is_failure_spike", "failure_rate"], ascending=[False, False])
