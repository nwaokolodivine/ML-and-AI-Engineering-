import numpy as np
import pandas as pd
from paymentpulse.config import DATA_DIR


def generate_demo_data(n=2500, seed=21):
    rng = np.random.default_rng(seed)
    merchants = [f"merchant_{i:02d}" for i in range(1, 13)]
    methods = ["CARD", "TRANSFER", "USSD", "WALLET"]
    statuses = rng.choice(
        ["SUCCESS", "FAILED", "PENDING", "REVERSED"],
        size=n, p=[0.82, 0.12, 0.04, 0.02]
    )
    created = pd.Timestamp("2026-10-01T00:00:00Z") + pd.to_timedelta(
        rng.integers(0, 30 * 24 * 60, n), unit="m"
    )
    delay = rng.integers(2, 75, n)
    completed = created + pd.to_timedelta(delay, unit="s")
    completed = pd.Series(completed, dtype="datetime64[ns, UTC]")
    completed[statuses != "SUCCESS"] = pd.NaT

    frame = pd.DataFrame({
        "transaction_id": [f"TXN-{i:06d}" for i in range(n)],
        "merchant_id": rng.choice(merchants, n),
        "amount": np.round(np.clip(rng.lognormal(8.1, 1.0, n), 100, 800000), 2),
        "currency": rng.choice(["NGN", "NGN", "NGN", "USD"], n),
        "status": statuses,
        "created_at": created,
        "completed_at": completed,
        "payment_method": rng.choice(methods, n),
    })
    # Inject a small, documented synthetic failure pocket for dashboard demonstration.
    pocket = (frame["merchant_id"] == "merchant_03") & (
        frame["created_at"].dt.day.isin([8, 9, 10])
    )
    indices = frame.index[pocket][:35]
    frame.loc[indices, "status"] = "FAILED"
    frame.loc[indices, "completed_at"] = pd.NaT
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    frame.to_csv(DATA_DIR / "demo_transactions.csv", index=False)
    print(f"Generated {len(frame)} synthetic transactions at {DATA_DIR / 'demo_transactions.csv'}")


if __name__ == "__main__":
    generate_demo_data()
