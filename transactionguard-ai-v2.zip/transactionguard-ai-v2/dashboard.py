import json
import os
from pathlib import Path
import requests
import streamlit as st

st.set_page_config(page_title="TransactionGuard AI", page_icon="🛡️", layout="wide")
st.title("🛡️ TransactionGuard AI")
st.caption("Fraud-risk scoring portfolio demo · simulated data only")
api_url = st.sidebar.text_input("API URL", os.getenv("API_URL", "http://localhost:8000"))

with st.sidebar:
    if st.button("Check API health"):
        try:
            st.json(requests.get(f"{api_url}/health", timeout=5).json())
        except requests.RequestException as exc:
            st.error(f"API unavailable: {exc}")

st.subheader("Score a transaction")
with st.form("transaction_form"):
    c1, c2, c3 = st.columns(3)
    amount = c1.number_input("Transaction amount", min_value=1.0, value=25000.0)
    hour = c2.slider("Hour of day", 0, 23, 14)
    day = c3.selectbox("Day of week (0 = Monday)", list(range(7)), index=2)
    international = c1.selectbox("International transaction", [0, 1], format_func=lambda x: "No" if x == 0 else "Yes")
    merchant_risk = c2.slider("Merchant risk indicator", 0.0, 1.0, 0.25)
    account_age = c3.number_input("Account age (days)", min_value=0, value=400)
    tx_count = c1.number_input("Transactions in last 24h", min_value=0, value=3)
    avg_amount = c2.number_input("Average transaction amount (7 days)", min_value=0.0, value=8000.0)
    distance = c3.number_input("Distance from home (km)", min_value=0.0, value=5.0)
    failed = c1.number_input("Failed attempts (24h)", min_value=0, value=0)
    submitted = st.form_submit_button("Evaluate transaction", type="primary")

if submitted:
    payload = {
        "amount": amount, "hour": hour, "day_of_week": day,
        "is_international": international, "merchant_risk": merchant_risk,
        "account_age_days": account_age, "transactions_last_24h": tx_count,
        "avg_amount_last_7d": avg_amount, "distance_from_home_km": distance,
        "failed_attempts_24h": failed,
    }
    try:
        response = requests.post(f"{api_url}/predict", json=payload, timeout=15)
        response.raise_for_status()
        result = response.json()
        st.metric("Model fraud score", f"{result['fraud_probability']:.1%}")
        st.subheader(f"Illustrative risk band: {result['risk_level']}")
        st.write("Suggested workflow:", result["recommended_action"])
        st.write("Input indicators:")
        for factor in result["risk_factors"]:
            st.write(f"- {factor}")
        st.warning(result["disclaimer"])
    except requests.RequestException as exc:
        st.error(f"Scoring request failed: {exc}")

metrics_path = Path("artifacts/training_metrics.json")
if metrics_path.exists():
    st.divider()
    st.subheader("Holdout evaluation")
    metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
    holdout = metrics["holdout_metrics"]
    a, b, c, d = st.columns(4)
    a.metric("ROC-AUC", f"{holdout['roc_auc']:.3f}")
    b.metric("Average precision", f"{holdout['average_precision']:.3f}")
    c.metric("Precision", f"{holdout['precision']:.3f}")
    d.metric("Recall", f"{holdout['recall']:.3f}")
    st.caption(
        f"Selected model: {metrics['selected_model']} · "
        f"Validation-selected threshold: {metrics['decision_threshold']:.3f}"
    )
    st.write("Model comparison")
    st.json(metrics["holdout_model_comparison"])
    st.write("Permutation importance (mean decrease in average precision)")
    st.bar_chart(metrics["permutation_importance"])
    st.caption("Permutation importance is global and model-agnostic; it is not a causal explanation.")
else:
    st.info("Train the model first to generate evaluation metrics.")
