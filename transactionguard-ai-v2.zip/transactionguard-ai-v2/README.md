# TransactionGuard AI
### Transaction Fraud Risk Scoring — End-to-End ML Portfolio Project

TransactionGuard AI is an educational end-to-end machine-learning prototype for transaction-risk scoring. It demonstrates reproducible synthetic data generation, model comparison, validation-based threshold selection, holdout evaluation, a FastAPI scoring service, and a Streamlit dashboard.

> **Important limitation:** Every transaction and fraud label in this repository is synthetically generated. The results do not represent the performance of a bank, payment processor, or real fraud system. This prototype must not be used to approve, decline, freeze, or block actual transactions.

## What it demonstrates

- Reproducible synthetic transaction data with a documented label-generation mechanism.
- A scikit-learn preprocessing and modelling pipeline.
- Logistic Regression and Random Forest comparison.
- Model selection using validation average precision.
- F2-based decision-threshold selection on a validation partition (not the holdout test set).
- Holdout evaluation using ROC-AUC, average precision, precision, recall, F1, confusion matrix, and classification report.
- Model-agnostic permutation importance.
- FastAPI endpoints for health, metrics, and prediction.
- Pydantic request validation and safe API error responses.
- Streamlit interface.
- Unit and API tests plus GitHub Actions CI.
- Docker Compose setup with a shared model-artifact volume.

## Architecture

```mermaid
flowchart TD
    A[Synthetic transaction generator] --> B[Stratified train / validation / test split]
    B --> C[Preprocessing pipeline]
    C --> D1[Logistic Regression]
    C --> D2[Random Forest]
    D1 --> E[Validation model selection]
    D2 --> E
    E --> F[Validation threshold tuning]
    F --> G[Refit selected model on training partition]
    G --> H[Untouched holdout evaluation]
    G --> I[Persist model artifact]
    I --> J[FastAPI scoring service]
    J --> K[Streamlit dashboard]
    H --> L[Metrics and permutation importance]
    L --> K
```

## Repository structure

```text
transactionguard-ai/
├── .github/workflows/tests.yml
├── artifacts/.gitkeep
├── src/
│   ├── config.py
│   ├── data.py
│   ├── evaluation.py
│   ├── risk.py
│   ├── schemas.py
│   ├── train.py
│   ├── service.py
│   └── api.py
├── tests/
│   ├── conftest.py
│   ├── test_api.py
│   ├── test_data.py
│   └── test_risk.py
├── dashboard.py
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
└── README.md
```

## Run locally (Windows PowerShell)

Use Python 3.11.

```powershell
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Train and evaluate:

```powershell
python -m src.train
```

Run the API in terminal 1:

```powershell
uvicorn src.api:app --reload
```

Run the dashboard in terminal 2:

```powershell
streamlit run dashboard.py
```

Open the dashboard at `http://localhost:8501` and API documentation at `http://localhost:8000/docs`.

## Run tests

```powershell
pytest -q
```

The GitHub Actions workflow runs the same test suite on pushes and pull requests.

## Run with Docker

```powershell
docker compose up --build
```

The API is exposed on port 8000 and the dashboard on port 8501. Docker Compose shares the generated model and metrics artifacts between the API and dashboard containers.

## API

- `GET /health` — API and model readiness.
- `GET /model/metrics` — training and holdout evaluation report.
- `POST /predict` — validates transaction fields and returns a model score, illustrative risk band, workflow suggestion, and heuristic input indicators.

Example request:

```json
{
  "amount": 25000,
  "hour": 14,
  "day_of_week": 2,
  "is_international": 0,
  "merchant_risk": 0.25,
  "account_age_days": 400,
  "transactions_last_24h": 3,
  "avg_amount_last_7d": 8000,
  "distance_from_home_km": 5,
  "failed_attempts_24h": 0
}
```

## Evaluation methodology

1. Split the generated data into a stratified training partition and a held-out test partition.
2. Create a validation partition from the training data.
3. Compare Logistic Regression and Random Forest using validation average precision.
4. Select the model with the higher validation average precision.
5. Select a decision threshold by maximizing F2 on validation predictions.
6. Refit candidate pipelines on the full training partition.
7. Report the selected model's results on the untouched test partition and include a test-set model comparison.

The test partition is not used for model selection or threshold selection. Because this is simulated data, this procedure demonstrates evaluation discipline but does not establish real-world generalization.

## Explainability: what the project does and does not claim

The dashboard reports **permutation importance**, a model-agnostic global measure of how much shuffling a feature affects average precision on the holdout data. The API also returns transparent, rule-based input indicators. Those indicators are not SHAP values, are not causal explanations, and should not be described as such.

An optional SHAP dependency is listed in `requirements-explainability.txt` for a future local explainability extension; the core project does not require SHAP to run.

## Production-readiness boundaries

This is a portfolio prototype, not a production payment-risk system. It currently does not provide authentication, authorization, rate limiting, customer-level isolation, encrypted feature storage, real-time streaming, drift monitoring, temporal backtesting, human-review operations, or a governed model registry. The threshold and risk bands are illustrative and are not calibrated to business costs.

A real payment system would require representative, lawfully obtained data; leakage review; temporal and out-of-time validation; calibration; cost-sensitive threshold selection; fairness and privacy review; monitoring; auditability; security controls; and controlled human oversight.

## Suggested interview walkthrough

Be ready to explain:
1. Why average precision is useful when the positive class is relatively rare.
2. Why threshold selection is separate from probability ranking.
3. Why the threshold is selected on validation data rather than the final test set.
4. What the confusion matrix says about false positives and false negatives.
5. What permutation importance measures and why it is not causal.
6. Why synthetic-data metrics cannot be used to claim banking-grade fraud detection.

## Reproducibility

The training script uses a fixed random seed by default. Re-running `python -m src.train` regenerates the synthetic data, model artifact, and evaluation report. Generated artifacts are ignored by Git so that the repository remains lightweight; the README and source code document how to reproduce them.
