import numpy as np
from sklearn.metrics import precision_recall_curve


def choose_f2_threshold(y_true, probabilities):
    """Choose the threshold maximizing F2 on a validation set (recall-weighted)."""
    precision, recall, thresholds = precision_recall_curve(y_true, probabilities)
    if len(thresholds) == 0:
        return 0.5
    p, r = precision[:-1], recall[:-1]
    f2 = (5 * p * r) / (4 * p + r + 1e-12)
    best = int(np.nanargmax(f2))
    return float(np.clip(thresholds[best], 0.01, 0.99))
