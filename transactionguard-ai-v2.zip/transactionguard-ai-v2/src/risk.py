def risk_level(probability: float) -> tuple[str, str]:
    if probability >= 0.70:
        return "HIGH", "REVIEW"
    if probability >= 0.30:
        return "MEDIUM", "STEP_UP_AUTHENTICATION"
    return "LOW", "ALLOW_SUBJECT_TO_POLICY"


def explain_input(row: dict) -> list[str]:
    """Readable input heuristics; these are not explanations of model causality."""
    signals = []
    if row["amount"] > max(2.5 * row["avg_amount_last_7d"], 500):
        signals.append("Amount is high relative to the recent transaction average.")
    if row["is_international"]:
        signals.append("Transaction is marked as international.")
    if row["merchant_risk"] >= 0.65:
        signals.append("Merchant-risk input is elevated.")
    if row["distance_from_home_km"] >= 300:
        signals.append("Transaction is far from the recorded home location.")
    if row["failed_attempts_24h"] >= 2:
        signals.append("Multiple failed attempts occurred in the last 24 hours.")
    if row["account_age_days"] < 30:
        signals.append("The account is relatively new.")
    if row["hour"] <= 4 or row["hour"] >= 23:
        signals.append("Transaction occurred during late-night or early-morning hours.")
    return signals or ["No configured heuristic input signals were triggered."]
