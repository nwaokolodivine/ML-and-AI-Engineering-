from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[1]
ARTIFACT_DIR = BASE_DIR / "artifacts"
MODEL_PATH = ARTIFACT_DIR / "fraud_pipeline.joblib"
METRICS_PATH = ARTIFACT_DIR / "training_metrics.json"

FEATURES = [
    "amount", "hour", "day_of_week", "is_international", "merchant_risk",
    "account_age_days", "transactions_last_24h", "avg_amount_last_7d",
    "distance_from_home_km", "failed_attempts_24h",
]
MODEL_VERSION = "transactionguard-v2"
