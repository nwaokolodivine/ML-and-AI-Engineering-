import json
import joblib
import pandas as pd
from src.config import MODEL_PATH, METRICS_PATH, FEATURES, MODEL_VERSION
from src.risk import risk_level, explain_input


class FraudScoringService:
    def __init__(self):
        if not MODEL_PATH.exists():
            raise FileNotFoundError("Model not found. Run `python -m src.train` first.")
        self.pipeline = joblib.load(MODEL_PATH)
        self.threshold = 0.5
        if METRICS_PATH.exists():
            metrics = json.loads(METRICS_PATH.read_text(encoding="utf-8"))
            self.threshold = float(metrics.get("decision_threshold", 0.5))

    def predict(self, payload: dict) -> dict:
        row = {key: payload[key] for key in FEATURES}
        frame = pd.DataFrame([row], columns=FEATURES)
        probability = float(self.pipeline.predict_proba(frame)[0, 1])
        level, action = risk_level(probability)
        return {
            "fraud_probability": round(probability, 6),
            "risk_level": level,
            "recommended_action": action,
            "model_version": MODEL_VERSION,
            "risk_factors": explain_input(row),
            "decision_threshold": self.threshold,
            "threshold_alert": bool(probability >= self.threshold),
            "disclaimer": (
                "Experimental decision-support output from a model trained on synthetic data. "
                "Do not use it to approve, decline, freeze, or block real transactions."
            ),
        }
