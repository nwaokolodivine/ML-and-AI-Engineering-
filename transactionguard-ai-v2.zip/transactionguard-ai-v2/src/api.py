from contextlib import asynccontextmanager
import json
import logging
from fastapi import FastAPI, HTTPException
from src.schemas import TransactionRequest, PredictionResponse
from src.service import FraudScoringService
from src.config import METRICS_PATH

logger = logging.getLogger(__name__)
service = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global service
    try:
        service = FraudScoringService()
        logger.info("Fraud scoring model loaded.")
    except FileNotFoundError:
        service = None
        logger.warning("Model artifact missing; train the model before prediction.")
    yield
    service = None


app = FastAPI(
    title="TransactionGuard AI",
    version="2.0.0",
    description="Portfolio demonstration API using simulated transaction data.",
    lifespan=lifespan,
)


@app.get("/health")
def health():
    return {
        "status": "ok",
        "model_loaded": service is not None,
        "instruction": None if service else "Run `python -m src.train` before scoring.",
    }


@app.get("/model/metrics")
def model_metrics():
    if not METRICS_PATH.exists():
        raise HTTPException(status_code=404, detail="Training metrics not found.")
    return json.loads(METRICS_PATH.read_text(encoding="utf-8"))


@app.post("/predict", response_model=PredictionResponse)
def predict(transaction: TransactionRequest):
    if service is None:
        raise HTTPException(status_code=503, detail="Model is not loaded. Train it first.")
    try:
        return service.predict(transaction.model_dump())
    except Exception:
        logger.exception("Prediction failed.")
        raise HTTPException(status_code=500, detail="Prediction failed; check server logs.")
