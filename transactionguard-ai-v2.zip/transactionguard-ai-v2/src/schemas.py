from pydantic import BaseModel, Field, ConfigDict


class TransactionRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    amount: float = Field(gt=0, le=10_000_000)
    hour: int = Field(ge=0, le=23)
    day_of_week: int = Field(ge=0, le=6)
    is_international: int = Field(ge=0, le=1)
    merchant_risk: float = Field(ge=0, le=1)
    account_age_days: int = Field(ge=0, le=100_000)
    transactions_last_24h: int = Field(ge=0, le=10_000)
    avg_amount_last_7d: float = Field(ge=0, le=10_000_000)
    distance_from_home_km: float = Field(ge=0, le=100_000)
    failed_attempts_24h: int = Field(ge=0, le=10_000)


class PredictionResponse(BaseModel):
    fraud_probability: float
    risk_level: str
    recommended_action: str
    model_version: str
    risk_factors: list[str]
    decision_threshold: float
    threshold_alert: bool
    disclaimer: str
