import json
import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    average_precision_score, classification_report, confusion_matrix,
    f1_score, precision_score, recall_score, roc_auc_score,
)
from sklearn.inspection import permutation_importance

from src.config import ARTIFACT_DIR, MODEL_PATH, METRICS_PATH, FEATURES, MODEL_VERSION
from src.data import generate_transactions
from src.evaluation import choose_f2_threshold


def _build_pipeline(model):
    preprocessing = ColumnTransformer([
        ("numeric", Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ]), FEATURES)
    ])
    return Pipeline([("preprocessing", preprocessing), ("classifier", model)])


def _metric_pack(y_true, probabilities, threshold):
    predictions = (probabilities >= threshold).astype(int)
    return {
        "roc_auc": float(roc_auc_score(y_true, probabilities)),
        "average_precision": float(average_precision_score(y_true, probabilities)),
        "precision": float(precision_score(y_true, predictions, zero_division=0)),
        "recall": float(recall_score(y_true, predictions, zero_division=0)),
        "f1": float(f1_score(y_true, predictions, zero_division=0)),
        "confusion_matrix": confusion_matrix(y_true, predictions).tolist(),
        "classification_report": classification_report(
            y_true, predictions, output_dict=True, zero_division=0
        ),
    }


def train(n_samples: int = 15000, random_state: int = 42):
    ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)
    df = generate_transactions(n_samples=n_samples, random_state=random_state)
    X, y = df[FEATURES], df["is_fraud"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=random_state, stratify=y
    )
    X_fit, X_val, y_fit, y_val = train_test_split(
        X_train, y_train, test_size=0.20, random_state=random_state, stratify=y_train
    )

    candidates = {
        "logistic_regression": LogisticRegression(
            max_iter=1500, class_weight="balanced", solver="lbfgs"
        ),
        "random_forest": RandomForestClassifier(
            n_estimators=300, max_depth=12, min_samples_leaf=3,
            class_weight="balanced_subsample", random_state=random_state,
            n_jobs=-1,
        ),
    }

    validation_scores = {}
    for name, estimator in candidates.items():
        candidate = _build_pipeline(estimator)
        candidate.fit(X_fit, y_fit)
        val_prob = candidate.predict_proba(X_val)[:, 1]
        validation_scores[name] = {
            "average_precision": float(average_precision_score(y_val, val_prob)),
            "roc_auc": float(roc_auc_score(y_val, val_prob)),
        }

    selected_name = max(
        validation_scores, key=lambda name: validation_scores[name]["average_precision"]
    )
    selected_threshold_model = _build_pipeline(candidates[selected_name])
    selected_threshold_model.fit(X_fit, y_fit)
    validation_prob = selected_threshold_model.predict_proba(X_val)[:, 1]
    threshold = choose_f2_threshold(y_val, validation_prob)

    # Refit each candidate on the full training partition for fair holdout comparison.
    holdout_comparison = {}
    fitted_candidates = {}
    for name, estimator in candidates.items():
        fitted = _build_pipeline(estimator)
        fitted.fit(X_train, y_train)
        probs = fitted.predict_proba(X_test)[:, 1]
        holdout_comparison[name] = _metric_pack(y_test, probs, threshold)
        fitted_candidates[name] = fitted

    final_model = fitted_candidates[selected_name]
    final_prob = final_model.predict_proba(X_test)[:, 1]
    final_metrics = _metric_pack(y_test, final_prob, threshold)

    # Model-agnostic permutation importance on the untouched holdout partition.
    permutation = permutation_importance(
        final_model, X_test, y_test, scoring="average_precision",
        n_repeats=5, random_state=random_state, n_jobs=-1,
    )
    importance = {
        feature: float(value)
        for feature, value in zip(FEATURES, permutation.importances_mean)
    }

    metrics = {
        "project": "TransactionGuard AI",
        "model_version": MODEL_VERSION,
        "dataset": "synthetic",
        "dataset_notice": "All records and labels are simulated; metrics do not represent bank performance.",
        "samples": int(n_samples),
        "fraud_rate": float(y.mean()),
        "selected_model": selected_name,
        "validation_model_selection": validation_scores,
        "decision_threshold": threshold,
        "threshold_selection": "F2 maximization on validation partition only",
        "holdout_metrics": final_metrics,
        "holdout_model_comparison": holdout_comparison,
        "permutation_importance": importance,
        "split": {"train": int(len(X_train)), "test": int(len(X_test))},
    }

    joblib.dump(final_model, MODEL_PATH)
    METRICS_PATH.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    df.to_csv(ARTIFACT_DIR / "synthetic_transactions.csv", index=False)
    print(f"Selected model: {selected_name}")
    print(f"Validation-selected threshold: {threshold:.3f}")
    print(f"Holdout ROC-AUC: {final_metrics['roc_auc']:.4f}")
    print(f"Holdout average precision: {final_metrics['average_precision']:.4f}")
    print(f"Artifacts saved in {ARTIFACT_DIR}")
    return metrics


if __name__ == "__main__":
    train()
