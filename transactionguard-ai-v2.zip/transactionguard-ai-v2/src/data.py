import numpy as np
import pandas as pd


def generate_transactions(n_samples: int = 15000, random_state: int = 42) -> pd.DataFrame:
    """Create reproducible synthetic transactions; these are not real banking records."""
    if n_samples < 200:
        raise ValueError("n_samples must be at least 200.")

    rng = np.random.default_rng(random_state)
    amount = np.clip(rng.lognormal(3.5, 1.15, n_samples), 1, 50000)
    hour = rng.integers(0, 24, n_samples)
    day = rng.integers(0, 7, n_samples)
    international = rng.binomial(1, 0.12, n_samples)
    merchant_risk = rng.beta(2, 5, n_samples)
    account_age = np.clip(rng.exponential(900, n_samples).astype(int), 1, 5000)
    tx_24h = np.clip(rng.poisson(2.2, n_samples), 0, 25)
    avg_7d = np.clip(rng.lognormal(3.2, 0.8, n_samples), 1, 20000)
    distance = np.clip(rng.exponential(18, n_samples), 0, 1500)
    failed = np.clip(rng.poisson(0.25, n_samples), 0, 8)

    # Transparent synthetic label-generation rule with stochastic noise.
    logit = (
        -5.1 + 0.000055 * amount + 1.25 * international
        + 3.0 * merchant_risk + 0.00045 * distance + 0.34 * failed
        + 0.12 * tx_24h
        + 0.00045 * np.maximum(amount - avg_7d * 2.5, 0)
        + 0.75 * (account_age < 30)
        + 0.65 * ((hour <= 4) | (hour >= 23))
    )
    probability = np.clip(1 / (1 + np.exp(-logit)), 0.002, 0.65)
    fraud = rng.binomial(1, probability)

    return pd.DataFrame({
        "amount": amount.round(2), "hour": hour, "day_of_week": day,
        "is_international": international, "merchant_risk": merchant_risk.round(4),
        "account_age_days": account_age, "transactions_last_24h": tx_24h,
        "avg_amount_last_7d": avg_7d.round(2),
        "distance_from_home_km": distance.round(2),
        "failed_attempts_24h": failed, "is_fraud": fraud,
    })
