from fastapi.testclient import TestClient


def _missing_model():
    class MissingModel:
        def __init__(self):
            raise FileNotFoundError("model not present in isolated test")
    return MissingModel


def test_health_endpoint_without_model(monkeypatch):
    import src.api as api_module
    monkeypatch.setattr(api_module, "FraudScoringService", _missing_model())
    with TestClient(api_module.app) as client:
        response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["model_loaded"] is False


def test_prediction_requires_loaded_model(monkeypatch):
    import src.api as api_module
    monkeypatch.setattr(api_module, "FraudScoringService", _missing_model())
    payload = {
        "amount": 1000, "hour": 12, "day_of_week": 2,
        "is_international": 0, "merchant_risk": 0.2,
        "account_age_days": 500, "transactions_last_24h": 2,
        "avg_amount_last_7d": 1500, "distance_from_home_km": 4,
        "failed_attempts_24h": 0,
    }
    with TestClient(api_module.app) as client:
        response = client.post("/predict", json=payload)
    assert response.status_code == 503


def test_prediction_returns_valid_response(monkeypatch):
    import src.api as api_module

    class FakeService:
        def __init__(self):
            pass
        def predict(self, payload):
            return {
                "fraud_probability": 0.42, "risk_level": "MEDIUM",
                "recommended_action": "STEP_UP_AUTHENTICATION",
                "model_version": "test-model", "risk_factors": ["test signal"],
                "decision_threshold": 0.4, "threshold_alert": True,
                "disclaimer": "test only",
            }

    monkeypatch.setattr(api_module, "FraudScoringService", FakeService)
    payload = {
        "amount": 1000, "hour": 12, "day_of_week": 2,
        "is_international": 0, "merchant_risk": 0.2,
        "account_age_days": 500, "transactions_last_24h": 2,
        "avg_amount_last_7d": 1500, "distance_from_home_km": 4,
        "failed_attempts_24h": 0,
    }
    with TestClient(api_module.app) as client:
        response = client.post("/predict", json=payload)
    assert response.status_code == 200
    assert response.json()["threshold_alert"] is True


def test_invalid_payload_is_rejected():
    from src.api import app
    with TestClient(app) as client:
        response = client.post("/predict", json={"amount": -5})
    assert response.status_code == 422
