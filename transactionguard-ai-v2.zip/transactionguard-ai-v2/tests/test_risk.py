from src.risk import risk_level, explain_input


def test_risk_bands():
    assert risk_level(0.1)[0] == "LOW"
    assert risk_level(0.5)[0] == "MEDIUM"
    assert risk_level(0.9)[0] == "HIGH"


def test_input_signals_are_returned():
    row = {
        "amount": 50000, "avg_amount_last_7d": 1000,
        "is_international": 1, "merchant_risk": 0.9,
        "distance_from_home_km": 500, "failed_attempts_24h": 3,
        "account_age_days": 10, "hour": 2,
    }
    assert len(explain_input(row)) >= 5
