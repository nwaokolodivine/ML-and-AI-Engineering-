from src.data import generate_transactions


def test_synthetic_data_is_reproducible():
    assert generate_transactions(300, 7).equals(generate_transactions(300, 7))


def test_target_is_binary():
    df = generate_transactions(300, 8)
    assert set(df["is_fraud"].unique()).issubset({0, 1})


def test_rejects_too_small_dataset():
    import pytest
    with pytest.raises(ValueError):
        generate_transactions(50)
