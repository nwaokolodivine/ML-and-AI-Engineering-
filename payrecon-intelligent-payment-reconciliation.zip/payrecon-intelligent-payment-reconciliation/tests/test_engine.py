import pytest
from payrecon.engine import reconcile

P = [
    {"provider_txn_id": "p1", "reference": "r1", "amount": "100.00", "currency": "NGN", "timestamp": "2026-01-01T10:00:00Z", "status": "SUCCESS"},
    {"provider_txn_id": "p2", "reference": "r2", "amount": "200.00", "currency": "NGN", "timestamp": "2026-01-01T11:00:00Z", "status": "SUCCESS"},
    {"provider_txn_id": "p3", "reference": "r3", "amount": "300.00", "currency": "NGN", "timestamp": "2026-01-01T12:00:00Z", "status": "SUCCESS"},
]
L = [
    {"ledger_entry_id": "l1", "reference": "r1", "amount": "100.00", "currency": "NGN", "timestamp": "2026-01-01T10:01:00Z", "status": "POSTED"},
    {"ledger_entry_id": "l2", "reference": "r2", "amount": "210.00", "currency": "NGN", "timestamp": "2026-01-01T11:00:00Z", "status": "POSTED"},
    {"ledger_entry_id": "l3", "reference": "different", "amount": "300.00", "currency": "NGN", "timestamp": "2026-01-01T12:05:00Z", "status": "POSTED"},
    {"ledger_entry_id": "l4", "reference": "orphan", "amount": "50.00", "currency": "NGN", "timestamp": "2026-01-01T13:00:00Z", "status": "POSTED"},
]


def test_classifies_exact_amount_mismatch_possible_and_unmatched():
    result = reconcile(P, L)
    statuses = [row["status"] for row in result["results"]]
    assert statuses == ["MATCHED", "AMOUNT_MISMATCH", "POSSIBLE_MATCH", "UNMATCHED_LEDGER"]
    assert result["summary"]["matched_count"] == 1
    assert result["summary"]["exception_count"] == 3


def test_one_ledger_entry_cannot_be_used_twice():
    result = reconcile([P[0], {**P[0], "provider_txn_id": "p-new"}], [L[0]])
    assert sum(row["ledger_entry_id"] == "l1" for row in result["results"]) == 1
    assert result["summary"]["status_counts"]["UNMATCHED_PROVIDER"] == 1


def test_currency_must_match_for_candidate():
    provider = [P[0]]
    ledger = [{**L[0], "currency": "USD"}]
    result = reconcile(provider, ledger)
    assert result["results"][0]["status"] == "UNMATCHED_PROVIDER"


def test_duplicate_ids_are_rejected():
    with pytest.raises(ValueError, match="Duplicate provider transaction ID"):
        reconcile([P[0], P[0]], [L[0]])


def test_invalid_amount_is_rejected():
    with pytest.raises(ValueError, match="Invalid monetary amount"):
        reconcile([{**P[0], "amount": "not-money"}], [L[0]])


def test_time_window_blocks_possible_match():
    provider = [{**P[2], "reference": "unknown"}]
    ledger = [{**L[2], "timestamp": "2026-01-02T12:00:00Z"}]
    result = reconcile(provider, ledger, time_tolerance_minutes=30)
    assert result["results"][0]["status"] == "UNMATCHED_PROVIDER"
