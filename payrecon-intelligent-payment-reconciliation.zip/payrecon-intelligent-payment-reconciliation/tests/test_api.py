from fastapi.testclient import TestClient
from payrecon.api import app


def test_health():
    with TestClient(app) as client:
        response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_reconcile_upload():
    provider = (
        "provider_txn_id,reference,amount,currency,timestamp,status\n"
        "p1,r1,100.00,NGN,2026-01-01T10:00:00Z,SUCCESS\n"
    )
    ledger = (
        "ledger_entry_id,reference,amount,currency,timestamp,status\n"
        "l1,r1,100.00,NGN,2026-01-01T10:01:00Z,POSTED\n"
    )
    with TestClient(app) as client:
        response = client.post(
            "/reconcile",
            files={
                "provider_file": ("provider.csv", provider, "text/csv"),
                "ledger_file": ("ledger.csv", ledger, "text/csv"),
            },
        )
    assert response.status_code == 200
    assert response.json()["summary"]["matched_count"] == 1
    assert response.json()["results"][0]["status"] == "MATCHED"


def test_missing_columns_returns_client_error():
    with TestClient(app) as client:
        response = client.post(
            "/reconcile",
            files={
                "provider_file": ("provider.csv", "id,amount\nx,1", "text/csv"),
                "ledger_file": ("ledger.csv", "id,amount\ny,1", "text/csv"),
            },
        )
    assert response.status_code == 400
