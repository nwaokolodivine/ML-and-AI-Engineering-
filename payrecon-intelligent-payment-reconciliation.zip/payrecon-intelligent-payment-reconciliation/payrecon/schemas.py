from pydantic import BaseModel, Field


class ReconciliationOptions(BaseModel):
    time_tolerance_minutes: int = Field(default=180, ge=0, le=10080)
    amount_tolerance: float = Field(default=0.01, ge=0, le=1000)
