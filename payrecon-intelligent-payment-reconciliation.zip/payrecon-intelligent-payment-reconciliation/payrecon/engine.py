from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from typing import Any


def _decimal(value: Any) -> Decimal:
    try:
        amount = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ValueError(f"Invalid monetary amount: {value!r}")
    if not amount.is_finite():
        raise ValueError(f"Amount must be finite: {value!r}")
    return amount.quantize(Decimal("0.01"))


def _timestamp(value: Any) -> datetime:
    raw = str(value).strip().replace("Z", "+00:00")
    parsed = datetime.fromisoformat(raw)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _normalise(rows: list[dict], id_field: str, source: str) -> list[dict]:
    cleaned = []
    seen_ids = set()
    for index, original in enumerate(rows):
        row = dict(original)
        for key in (id_field, "reference", "currency", "timestamp", "status", "amount"):
            if key not in row or row[key] is None or str(row[key]).strip() == "":
                raise ValueError(f"{source} row {index + 1} is missing required field '{key}'.")
        row[id_field] = str(row[id_field]).strip()
        if row[id_field] in seen_ids:
            raise ValueError(f"Duplicate {source} transaction ID: {row[id_field]}")
        seen_ids.add(row[id_field])
        row["reference"] = str(row["reference"]).strip()
        row["currency"] = str(row["currency"]).strip().upper()
        row["status"] = str(row["status"]).strip().upper()
        row["_amount"] = _decimal(row["amount"])
        row["_time"] = _timestamp(row["timestamp"])
        cleaned.append(row)
    return cleaned


def reconcile(
    provider_rows: list[dict],
    ledger_rows: list[dict],
    time_tolerance_minutes: int = 180,
    amount_tolerance: float = 0.01,
) -> dict:
    """One-to-one reconciliation with explainable matching priorities.

    Priority 1: same reference + currency + amount.
    Priority 2: same reference + currency, but amount differs.
    Priority 3: same amount + currency within time tolerance (reference may differ).
    Remaining records are unmatched. A ledger entry can be consumed only once.
    """
    if time_tolerance_minutes < 0 or amount_tolerance < 0:
        raise ValueError("Tolerances cannot be negative.")

    provider = _normalise(provider_rows, "provider_txn_id", "provider")
    ledger = _normalise(ledger_rows, "ledger_entry_id", "ledger")
    available = set(range(len(ledger)))
    results = []
    consumed_ledger = set()

    def time_gap_minutes(a, b):
        return abs((a["_time"] - b["_time"]).total_seconds()) / 60

    for p in provider:
        candidates = [i for i in available if ledger[i]["currency"] == p["currency"]]
        same_ref = [i for i in candidates if ledger[i]["reference"] == p["reference"]]
        exact = [
            i for i in same_ref
            if abs(ledger[i]["_amount"] - p["_amount"]) <= Decimal(str(amount_tolerance))
        ]

        chosen = None
        status = None
        reason = None

        if exact:
            chosen = min(exact, key=lambda i: time_gap_minutes(p, ledger[i]))
            status = "MATCHED"
            reason = "Reference, currency and amount matched."
        elif same_ref:
            chosen = min(same_ref, key=lambda i: time_gap_minutes(p, ledger[i]))
            status = "AMOUNT_MISMATCH"
            reason = "Reference and currency matched, but amount differs."
        else:
            fuzzy = [
                i for i in candidates
                if abs(ledger[i]["_amount"] - p["_amount"]) <= Decimal(str(amount_tolerance))
                and time_gap_minutes(p, ledger[i]) <= time_tolerance_minutes
            ]
            if fuzzy:
                chosen = min(
                    fuzzy,
                    key=lambda i: (time_gap_minutes(p, ledger[i]), ledger[i]["ledger_entry_id"])
                )
                status = "POSSIBLE_MATCH"
                reason = "Amount and currency matched within the time window, but reference differs."

        if chosen is not None:
            matched_ledger = ledger[chosen]
            available.remove(chosen)
            consumed_ledger.add(chosen)
            results.append({
                "provider_txn_id": p["provider_txn_id"],
                "ledger_entry_id": matched_ledger["ledger_entry_id"],
                "provider_reference": p["reference"],
                "ledger_reference": matched_ledger["reference"],
                "provider_amount": str(p["_amount"]),
                "ledger_amount": str(matched_ledger["_amount"]),
                "currency": p["currency"],
                "status": status,
                "reason": reason,
                "time_difference_minutes": round(time_gap_minutes(p, matched_ledger), 2),
            })
        else:
            results.append({
                "provider_txn_id": p["provider_txn_id"],
                "ledger_entry_id": None,
                "provider_reference": p["reference"],
                "ledger_reference": None,
                "provider_amount": str(p["_amount"]),
                "ledger_amount": None,
                "currency": p["currency"],
                "status": "UNMATCHED_PROVIDER",
                "reason": "No eligible ledger entry was found.",
                "time_difference_minutes": None,
            })

    for i, entry in enumerate(ledger):
        if i not in consumed_ledger:
            results.append({
                "provider_txn_id": None,
                "ledger_entry_id": entry["ledger_entry_id"],
                "provider_reference": None,
                "ledger_reference": entry["reference"],
                "provider_amount": None,
                "ledger_amount": str(entry["_amount"]),
                "currency": entry["currency"],
                "status": "UNMATCHED_LEDGER",
                "reason": "No provider transaction was matched to this ledger entry.",
                "time_difference_minutes": None,
            })

    counts = {}
    for row in results:
        counts[row["status"]] = counts.get(row["status"], 0) + 1

    provider_total = sum((r["_amount"] for r in provider), Decimal("0.00"))
    ledger_total = sum((r["_amount"] for r in ledger), Decimal("0.00"))
    return {
        "summary": {
            "provider_count": len(provider),
            "ledger_count": len(ledger),
            "result_count": len(results),
            "status_counts": counts,
            "provider_total": str(provider_total),
            "ledger_total": str(ledger_total),
            "net_difference": str((provider_total - ledger_total).quantize(Decimal("0.01"))),
            "matched_count": counts.get("MATCHED", 0),
            "exception_count": sum(v for k, v in counts.items() if k != "MATCHED"),
        },
        "results": results,
    }
