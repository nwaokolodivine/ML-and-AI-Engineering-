from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = BASE_DIR / "data"
DATABASE_PATH = DATA_DIR / "payrecon.db"

PROVIDER_REQUIRED = {"provider_txn_id", "reference", "amount", "currency", "timestamp", "status"}
LEDGER_REQUIRED = {"ledger_entry_id", "reference", "amount", "currency", "timestamp", "status"}
