import json
import sqlite3
from datetime import datetime, timezone
from payrecon.config import DATABASE_PATH, DATA_DIR


def save_run(result: dict) -> int:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(DATABASE_PATH) as connection:
        connection.execute("""
            CREATE TABLE IF NOT EXISTS reconciliation_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                summary_json TEXT NOT NULL,
                results_json TEXT NOT NULL
            )
        """)
        cursor = connection.execute(
            "INSERT INTO reconciliation_runs (created_at, summary_json, results_json) VALUES (?, ?, ?)",
            (
                datetime.now(timezone.utc).isoformat(),
                json.dumps(result["summary"]),
                json.dumps(result["results"]),
            ),
        )
        return int(cursor.lastrowid)


def list_runs(limit: int = 20) -> list[dict]:
    if not DATABASE_PATH.exists():
        return []
    with sqlite3.connect(DATABASE_PATH) as connection:
        connection.row_factory = sqlite3.Row
        rows = connection.execute(
            "SELECT id, created_at, summary_json FROM reconciliation_runs ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
    return [
        {
            "id": row["id"],
            "created_at": row["created_at"],
            "summary": json.loads(row["summary_json"]),
        }
        for row in rows
    ]
