import csv
from pathlib import Path
from payrecon.config import DATA_DIR


def generate_demo_files():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    provider = [
        {"provider_txn_id": "P-1001", "reference": "REF-001", "amount": "2500.00", "currency": "NGN", "timestamp": "2026-11-17T09:00:00Z", "status": "SUCCESS"},
        {"provider_txn_id": "P-1002", "reference": "REF-002", "amount": "7500.00", "currency": "NGN", "timestamp": "2026-11-17T09:15:00Z", "status": "SUCCESS"},
        {"provider_txn_id": "P-1003", "reference": "REF-003", "amount": "1200.00", "currency": "NGN", "timestamp": "2026-11-17T10:00:00Z", "status": "SUCCESS"},
        {"provider_txn_id": "P-1004", "reference": "REF-004", "amount": "4000.00", "currency": "NGN", "timestamp": "2026-11-17T11:30:00Z", "status": "SUCCESS"},
        {"provider_txn_id": "P-1005", "reference": "REF-005", "amount": "900.00", "currency": "NGN", "timestamp": "2026-11-17T12:00:00Z", "status": "SUCCESS"},
        {"provider_txn_id": "P-1006", "reference": "REF-006", "amount": "3000.00", "currency": "NGN", "timestamp": "2026-11-17T13:00:00Z", "status": "SUCCESS"},
    ]
    ledger = [
        {"ledger_entry_id": "L-2001", "reference": "REF-001", "amount": "2500.00", "currency": "NGN", "timestamp": "2026-11-17T09:01:00Z", "status": "POSTED"},
        {"ledger_entry_id": "L-2002", "reference": "REF-002", "amount": "7000.00", "currency": "NGN", "timestamp": "2026-11-17T09:15:00Z", "status": "POSTED"},
        {"ledger_entry_id": "L-2003", "reference": "REF-003-ALT", "amount": "1200.00", "currency": "NGN", "timestamp": "2026-11-17T10:10:00Z", "status": "POSTED"},
        {"ledger_entry_id": "L-2004", "reference": "REF-004", "amount": "4000.00", "currency": "NGN", "timestamp": "2026-11-17T11:31:00Z", "status": "POSTED"},
        {"ledger_entry_id": "L-2005", "reference": "REF-999", "amount": "1500.00", "currency": "NGN", "timestamp": "2026-11-17T12:30:00Z", "status": "POSTED"},
        {"ledger_entry_id": "L-2006", "reference": "REF-006", "amount": "3000.00", "currency": "NGN", "timestamp": "2026-11-17T13:00:00Z", "status": "POSTED"},
    ]
    for name, rows in [("provider_transactions.csv", provider), ("ledger_entries.csv", ledger)]:
        with (DATA_DIR / name).open("w", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
    print(f"Demo CSVs created in {DATA_DIR}")


if __name__ == "__main__":
    generate_demo_files()
