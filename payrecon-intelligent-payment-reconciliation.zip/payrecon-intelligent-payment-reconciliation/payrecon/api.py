import csv
import io
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import StreamingResponse
from payrecon.config import PROVIDER_REQUIRED, LEDGER_REQUIRED
from payrecon.engine import reconcile
from payrecon.schemas import ReconciliationOptions
from payrecon.storage import save_run, list_runs


app = FastAPI(
    title="PayRecon API",
    version="1.0.0",
    description="Payment provider-to-ledger reconciliation and exception management demo.",
)


def _read_csv(content: bytes, required: set[str], source: str) -> list[dict]:
    try:
        text = content.decode("utf-8-sig")
        reader = csv.DictReader(io.StringIO(text))
        if not reader.fieldnames:
            raise ValueError(f"{source} CSV is empty or has no header.")
        missing = required - set(reader.fieldnames)
        if missing:
            raise ValueError(f"{source} CSV is missing columns: {', '.join(sorted(missing))}")
        rows = list(reader)
        if not rows:
            raise ValueError(f"{source} CSV contains no transaction rows.")
        return rows
    except UnicodeDecodeError:
        raise ValueError(f"{source} CSV must be UTF-8 encoded.")


@app.get("/health")
def health():
    return {"status": "ok", "service": "payrecon-api"}


@app.get("/runs")
def runs(limit: int = 20):
    if limit < 1 or limit > 100:
        raise HTTPException(status_code=422, detail="limit must be between 1 and 100.")
    return {"runs": list_runs(limit)}


@app.post("/reconcile")
async def reconcile_files(
    provider_file: UploadFile = File(...),
    ledger_file: UploadFile = File(...),
    time_tolerance_minutes: int = 180,
    amount_tolerance: float = 0.01,
):
    if not provider_file.filename.lower().endswith(".csv") or not ledger_file.filename.lower().endswith(".csv"):
        raise HTTPException(status_code=415, detail="Upload two CSV files.")
    if time_tolerance_minutes < 0 or time_tolerance_minutes > 10080 or amount_tolerance < 0:
        raise HTTPException(status_code=422, detail="Invalid reconciliation tolerance.")
    try:
        provider_rows = _read_csv(await provider_file.read(), PROVIDER_REQUIRED, "Provider")
        ledger_rows = _read_csv(await ledger_file.read(), LEDGER_REQUIRED, "Ledger")
        result = reconcile(
            provider_rows, ledger_rows,
            time_tolerance_minutes=time_tolerance_minutes,
            amount_tolerance=amount_tolerance,
        )
        result["run_id"] = save_run(result)
        return result
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/reconcile/export")
async def reconcile_and_export(
    provider_file: UploadFile = File(...),
    ledger_file: UploadFile = File(...),
    time_tolerance_minutes: int = 180,
    amount_tolerance: float = 0.01,
):
    if not provider_file.filename.lower().endswith(".csv") or not ledger_file.filename.lower().endswith(".csv"):
        raise HTTPException(status_code=415, detail="Upload two CSV files.")
    try:
        result = reconcile(
            _read_csv(await provider_file.read(), PROVIDER_REQUIRED, "Provider"),
            _read_csv(await ledger_file.read(), LEDGER_REQUIRED, "Ledger"),
            time_tolerance_minutes, amount_tolerance,
        )
        output = io.StringIO()
        columns = list(result["results"][0].keys()) if result["results"] else []
        writer = csv.DictWriter(output, fieldnames=columns)
        writer.writeheader()
        writer.writerows(result["results"])
        return StreamingResponse(
            iter([output.getvalue()]),
            media_type="text/csv",
            headers={"Content-Disposition": 'attachment; filename="payrecon_exceptions.csv"'},
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
