import io
import os
import pandas as pd
import requests
import streamlit as st

st.set_page_config(page_title="PayRecon", page_icon="💳", layout="wide")
st.title("💳 PayRecon")
st.caption("Payment reconciliation & exception management · portfolio demonstration")
api_url = st.sidebar.text_input("API URL", os.getenv("API_URL", "http://localhost:8000"))

st.markdown(
    "Compare payment-provider settlements against an internal ledger. "
    "The engine prioritises exact matches, then identifies amount mismatches, "
    "possible reference discrepancies, and unmatched records."
)

provider_file = st.file_uploader("Provider transactions CSV", type=["csv"], key="provider")
ledger_file = st.file_uploader("Internal ledger CSV", type=["csv"], key="ledger")
col1, col2 = st.columns(2)
time_tolerance = col1.number_input("Possible-match time window (minutes)", 0, 10080, 180)
amount_tolerance = col2.number_input("Amount tolerance", 0.0, 1000.0, 0.01, format="%.2f")

if st.button("Run reconciliation", type="primary", disabled=not (provider_file and ledger_file)):
    try:
        response = requests.post(
            f"{api_url}/reconcile",
            files={
                "provider_file": (provider_file.name, provider_file.getvalue(), "text/csv"),
                "ledger_file": (ledger_file.name, ledger_file.getvalue(), "text/csv"),
            },
            params={
                "time_tolerance_minutes": int(time_tolerance),
                "amount_tolerance": float(amount_tolerance),
            },
            timeout=60,
        )
        response.raise_for_status()
        result = response.json()
        st.session_state["latest_result"] = result
    except requests.RequestException as exc:
        st.error(f"Reconciliation failed: {exc}")
        if getattr(exc, "response", None) is not None:
            st.error(exc.response.text)

result = st.session_state.get("latest_result")
if result:
    summary = result["summary"]
    st.divider()
    st.subheader(f"Reconciliation run #{result.get('run_id', 'export')}")
    a, b, c, d = st.columns(4)
    a.metric("Provider records", summary["provider_count"])
    b.metric("Ledger records", summary["ledger_count"])
    c.metric("Exact matches", summary["matched_count"])
    d.metric("Exceptions", summary["exception_count"])
    e, f, g = st.columns(3)
    e.metric("Provider total", f"{summary['provider_total']}")
    f.metric("Ledger total", f"{summary['ledger_total']}")
    g.metric("Net difference", f"{summary['net_difference']}")
    frame = pd.DataFrame(result["results"])
    st.subheader("Reconciliation results")
    selected = st.multiselect("Filter by status", sorted(frame["status"].unique()), default=sorted(frame["status"].unique()))
    st.dataframe(frame[frame["status"].isin(selected)], use_container_width=True, hide_index=True)
    st.download_button(
        "Download reconciliation results",
        frame.to_csv(index=False).encode("utf-8"),
        file_name="payrecon_results.csv",
        mime="text/csv",
    )
    st.caption("Possible matches are suggestions for human review, not automatic ledger adjustments.")

with st.expander("Required CSV columns"):
    st.code("Provider: provider_txn_id, reference, amount, currency, timestamp, status")
    st.code("Ledger: ledger_entry_id, reference, amount, currency, timestamp, status")
