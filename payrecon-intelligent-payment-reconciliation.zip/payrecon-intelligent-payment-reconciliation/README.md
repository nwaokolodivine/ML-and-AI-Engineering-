# PayRecon — Intelligent Payment Reconciliation

PayRecon is a portfolio project that reconciles payment-provider transaction exports against an internal ledger. It classifies exact matches, amount mismatches, possible reference mismatches, unmatched provider records, and unmatched ledger entries. It includes a FastAPI service, Streamlit dashboard, CSV export, SQLite run history, automated tests, and Docker configuration.

## Why this problem matters

Payment operations teams need to compare provider settlement reports with internal transaction ledgers. Differences can arise from delayed posting, incorrect amounts, missing entries, duplicated records, reference inconsistencies, or timing differences. PayRecon automates first-pass matching and surfaces exceptions for human review.

## Features

- CSV ingestion with required-column and data validation.
- One-to-one matching: a ledger entry cannot be consumed by multiple provider transactions.
- Explainable matching priority:
  1. Same reference, currency, and amount.
  2. Same reference and currency with an amount mismatch.
  3. Same amount and currency within a configurable time window, but different reference.
  4. Unmatched provider and ledger entries.
- Monetary arithmetic using Python `Decimal` to avoid binary floating-point rounding errors.
- Summary totals and exception counts.
- FastAPI endpoints for health, reconciliation, CSV export, and run history.
- SQLite persistence for reconciliation summaries and result records.
- Streamlit dashboard with status filtering and CSV download.
- Pytest unit and API tests plus GitHub Actions CI.

## Architecture

```mermaid
flowchart TD
    A[Provider CSV] --> C[FastAPI ingestion and validation]
    B[Internal ledger CSV] --> C
    C --> D[Reconciliation engine]
    D --> E[Exact reference and amount match]
    E --> F[Reference amount mismatch]
    F --> G[Time-window possible match]
    G --> H[Unmatched exceptions]
    D --> I[Summary and detailed results]
    I --> J[SQLite run history]
    I --> K[Streamlit dashboard]
    I --> L[CSV export]
```

## Project structure

```text
payrecon/
  api.py
  config.py
  demo_data.py
  engine.py
  schemas.py
  storage.py
tests/
  test_api.py
  test_engine.py
dashboard.py
Dockerfile
docker-compose.yml
requirements.txt
```

## Run locally on Windows (PowerShell)

Use Python 3.11.

```powershell
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m payrecon.demo_data
```

Start the API in terminal 1:

```powershell
uvicorn payrecon.api:app --reload
```

Start the dashboard in terminal 2:

```powershell
streamlit run dashboard.py
```

Open `http://localhost:8501` for the dashboard and `http://localhost:8000/docs` for interactive API documentation. Upload the two generated CSV files from the `data` directory.

## Run tests

```powershell
pytest -q
```

GitHub Actions runs this test suite on pushes and pull requests.

## Run with Docker

```powershell
docker compose up --build
```

The dashboard is available on port 8501 and the API on port 8000.

## CSV input formats

Provider CSV columns:

`provider_txn_id, reference, amount, currency, timestamp, status`

Ledger CSV columns:

`ledger_entry_id, reference, amount, currency, timestamp, status`

Timestamps should be ISO-8601. Naive timestamps are interpreted as UTC. Currency is normalised to uppercase. Amounts are parsed as decimal monetary values.

## API endpoints

- `GET /health` — service health.
- `GET /runs?limit=20` — recent saved reconciliation runs.
- `POST /reconcile` — upload `provider_file` and `ledger_file`; returns summary and detailed reconciliation results.
- `POST /reconcile/export` — upload the same files and receive a CSV of the reconciliation results.

## Important engineering boundaries

This is a portfolio prototype, not a bank-grade settlement platform. The matching engine is deterministic and rule-based; it is not a trained AI model. A `POSSIBLE_MATCH` is a candidate for human review, not a confirmed match. The current implementation does not include payment-rail integrations, authentication, role-based access, encryption/key management, high-volume streaming, currency conversion, settlement calendars, chargeback workflows, or automatic ledger posting.

Before production use, the system would need access controls, file-size and row-count limits, audit trails, idempotent ingestion, robust duplicate handling policies, maker-checker approval, reconciliation policy configuration, security testing, operational monitoring, and validation against real-world edge cases.

## Interview discussion points

Be prepared to explain:
- Why matching is one-to-one and how the engine prevents ledger-entry reuse.
- Why `Decimal` is preferable to binary floating-point for money.
- Why matching is prioritised from strongest evidence to weaker candidate evidence.
- Why possible matches are separated from confirmed matches.
- How you would add idempotency, audit history, approvals, and high-volume processing.
- Why the tool exports exceptions rather than automatically changing financial records.
